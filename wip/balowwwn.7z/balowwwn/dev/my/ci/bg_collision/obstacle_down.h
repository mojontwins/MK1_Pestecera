// MTE MK1 (la Churrera) v5.0
// Copyleft 2010-2014, 2020 by the Mojon Twins

// Attempt to break a breakable tile colliding vertically
// break_vertical is defined in extra_functions.h
break_vertical ();
