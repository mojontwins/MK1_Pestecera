// MTE MK1 (la Churrera) v5.0
// Copyleft 2010-2014, 2020 by the Mojon Twins

// Persist x0, y0 (write 0)
gpaux = COORDS (x0, y0); rdt = 0; modify_map ();

// Persist x1, y1 (write 14)
gpaux = COORDS (x1, y1); rdt = 14; modify_map ();
