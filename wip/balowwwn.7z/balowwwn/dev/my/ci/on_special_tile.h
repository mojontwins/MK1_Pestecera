// MTE MK1 (la Churrera) v5.0
// Copyleft 2010-2014, 2020 by the Mojon Twins

// This tile makes you go slower, attempt 1:

p_vx = p_vx >> 1;
p_vy = p_vy >> 1;
