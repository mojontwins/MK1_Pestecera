// MTE MK1 (la Churrera) v5.0
// Copyleft 2010-2014, 2020 by the Mojon Twins

// This code is ran just before looping back to the title screen

// COMPRESSED_LEVELS: Note that `continue` here would restart the main loop
// (i.e. reload current level).

