// MTE MK1 (la Churrera) v5.0
// Copyleft 2010-2014, 2020 by the Mojon Twins

// Sprites.h
// Generado por SprCnv de la Churrera
// Copyleft 2010 The Mojon Twins
 
extern unsigned char sprites [0]; 
 
#asm
	._sprites
		defs 64*16, 0
#endasm
 
