// MTE MK1 (la Churrera) v5.0
// Copyleft 2010-2014, 2020 by the Mojon Twins

// If DIE_AND_RESPAWN is on, this code is included when respawning the player
// in a safe spot so you can reset stuff.

// For example, add a pause.

espera_activa (50);
