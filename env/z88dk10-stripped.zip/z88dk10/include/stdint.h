/*
 *  stdint.h - integer types
 *
 *	$Id: stdint.h,v 1.1 2012/04/20 15:46:39 stefano Exp $
 */

#ifndef _STDINT_H
#define _STDINT_H

#include <sys/compiler.h>
#include <sys/types.h>

#endif

