// MTE MK1 (la Churrera) v5.0
// Copyleft 2010-2014, 2020 by the Mojon Twins

// This code is added just before the switch block which actually 
// checks the enemy type to make it move.

// Here you can do things like
/*
	if (enemies_are_paralyzed) {
		#asm
				jp	enems_just_moved
		#endasm	
	}
*/
// for example.
