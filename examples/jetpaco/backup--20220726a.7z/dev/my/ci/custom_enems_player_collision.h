// MTE MK1 (la Churrera) v5.0
// Copyleft 2010-2014, 2020 by the Mojon Twins

// To check custom collisions with the player.
// Runs after platforms (in lateral view games) have been discarded.

// Don't remember to bypass normal enemy/player collision (which results on the player losing life)
// if needed using 

// goto player_enem_collision_done;
