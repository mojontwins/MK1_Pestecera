// MTE MK1 (la Churrera) v5.0
// Copyleft 2010-2014, 2020 by the Mojon Twins

// This is run once per hotspot print in the map renderer. you can change A

// Notice! this won't change the hotspot #, just the tile printed

	#asm
			ld  c, a
			ld  a, (_hotspots_offset)
			add c
	#endasm
