// MTE MK1 (la Churrera) v5.0
// Copyleft 2010-2014, 2020 by the Mojon Twins

gm = 1;

tile_offset = gm_tile_offset [gm];
hotspots_offset = gm_hotspots_offset [gm];
pal_set (gm_palette [gm]);

gm_ts = gm_ts_list [gm];
