// MTE MK1 (la Churrera) v5.0
// Copyleft 2010-2014, 2020 by the Mojon Twins

// This code is ran just before looping back to the title screen

pal_set (my_inks);
