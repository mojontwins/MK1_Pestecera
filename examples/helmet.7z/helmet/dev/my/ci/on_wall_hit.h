// MTE MK1 (la Churrera) v5.0
// Copyleft 2010-2014, 2020 by the Mojon Twins

// _x, _y contain the tile coordinates.

_t = 31; draw_invalidate_coloured_tile_gamearea ();
