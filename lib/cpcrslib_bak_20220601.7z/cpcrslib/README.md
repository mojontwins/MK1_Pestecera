# Beware!

This version of CPCRSLIB has been heavily modified. The tilemap related functions are somewhat new and behave differently. They are definitely not general and not all-purpose. All sprite-related routines have been rewritten from scratch. Everything has been manually tallied and optimized for MK1. It may serve your puropose on a different engine but this is *not* the full, original & all-purpose CPCRSLIB.

Original version by Artaburu.
